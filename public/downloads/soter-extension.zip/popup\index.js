import{i as e,n as t,r as n,t as r}from"../chunks/enrollment-ui-Sm7PUNtC.js";function i(a,o){let s=o.enrollmentStatus===`enrolled`,c=o.policy?.emergencyLockdown?.enabled??!1,l=o.policy?.destinations?.some(e=>e.enabled&&e.responseScanningEnabled)??!1;a.innerHTML=`
    <style>
      body { margin:0; width:340px; font-family:Inter,ui-sans-serif,system-ui,sans-serif; color:#172033; background:#fff; }
      .shell { padding:14px; display:grid; gap:12px; } h1,h2,p { margin:0; } h1 { font-size:17px; } h2 { font-size:14px; }
      .pill { display:inline-flex; width:fit-content; border-radius:999px; padding:4px 9px; font-size:12px; font-weight:750; background:${c?`#fee4e2`:s?`#dcfae6`:`#fff3cd`}; color:${c?`#b42318`:s?`#067647`:`#7a4d00`}; }
      .rows,section { display:grid; gap:8px; border-top:1px solid #edf1f6; padding-top:10px; } .row { display:flex; justify-content:space-between; gap:12px; font-size:13px; } .value { font-weight:700; text-align:right; overflow-wrap:anywhere; }
      label { display:grid; gap:4px; font-size:12px; font-weight:700; } input { box-sizing:border-box; width:100%; border:1px solid #cbd5e1; border-radius:6px; padding:8px; } button { border:1px solid #1463ff; background:#1463ff; color:white; border-radius:6px; padding:8px 10px; font-weight:700; cursor:pointer; } button:disabled { opacity:.65; cursor:wait; }
      .help { color:#5f6f84; font-size:12px; line-height:1.4; } .error { color:#b42318; font-size:12px; } .lockdown { border:1px solid #fda29b; background:#fff1f0; color:#b42318; border-radius:7px; padding:9px; font-size:12px; font-weight:700; }
    </style>
    <div class="shell">
      <h1>Soter Enterprise</h1>
      <span class="pill" data-status>${n(t(o))}</span>
      ${c?`<div class="lockdown">Emergency lockdown is active. Strict organization policy is enforced from the offline cache.</div>`:``}
      ${s?`
        <div class="rows" data-enrollment-view="${o.enrollmentMode===`managed`?`managed`:`enrolled`}">
          <div class="row"><span>Organization</span><span class="value">${n(o.config.organizationName??o.config.organizationId)}</span></div>
          <div class="row"><span>Employee</span><span class="value">${n(o.config.employeeEmail??o.config.employeeId)}</span></div>
          <div class="row"><span>Department / role</span><span class="value">${n([o.config.department,o.config.role].filter(Boolean).join(` / `)||`Not assigned`)}</span></div>
          <div class="row"><span>Policy version</span><span class="value">${n(o.policy?.version??`unknown`)}</span></div>
          <div class="row"><span>Response scanning</span><span class="value">${l?`Enabled for configured AI destinations`:`Disabled`}</span></div>
          <div class="row"><span>Sync status</span><span class="value">${n(o.policySyncStatus)}</span></div>
          <div class="row"><span>Last heartbeat</span><span class="value">${n(o.lastHeartbeatAt??`never`)}</span></div>
        </div>
        <button data-heartbeat>Sync now</button>`:r(o)}
    </div>`,e(a,e=>i(a,e)),a.querySelector(`[data-heartbeat]`)?.addEventListener(`click`,()=>chrome.runtime.sendMessage({type:`SOTER_SYNC_POLICY`},e=>{let t=e?.state;t&&i(a,t)}))}var a=document.getElementById(`root`);a&&chrome.runtime.sendMessage({type:`SOTER_GET_STATE`},e=>{let t=e?.state;t&&i(a,t)});